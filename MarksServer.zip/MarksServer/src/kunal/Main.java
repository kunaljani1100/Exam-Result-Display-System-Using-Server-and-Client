package kunal;

public class Main
{

    public static void main(String[] args)
    {
        ShowMarks marks=new ShowMarks();
        marks.showMarks();
    }
}
