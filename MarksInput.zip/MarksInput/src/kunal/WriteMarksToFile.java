package kunal;

import java.io.*;
import java.util.ArrayList;

/**
 * Created by kunal on 19-08-2017.
 */
public class WriteMarksToFile {
    private StudentMarks marks=new StudentMarks();
    public void write()
    {
        marks.readMarks();
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(marks.getRollno()+".txt",true)))
        {
            BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter("rollnos.txt",true));
            bufferedWriter.write(marks.getRollno());
            bufferedWriter.close();
            writer.write(marks.getRollno()+"\n");
            writer.write(marks.getFirstName()+"\n");
            writer.write(marks.getLastName()+"\n");
            writer.write(marks.getEng()+"\n");
            writer.write(marks.getMaths()+"\n");
            writer.write(marks.getPhy()+"\n");
            writer.write(marks.getChem()+"\n");
            writer.write(marks.getComp()+"\n");
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
