package kunal;

import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Created by kunal on 19-08-2017.
 */
public class ChangeMarks {
    Scanner scanner=new Scanner(System.in);
    String rollno;
    StudentMarks records=new StudentMarks();
    public void change()
    {

        System.out.println("Enter the roll number of the student whose marks you want to change:");
        rollno=scanner.nextLine();
        try
        {
            boolean success=new File(rollno+".txt").delete();
            records.readMarks();
            BufferedWriter writer=new BufferedWriter(new FileWriter(rollno+".txt"));
            writer.write(records.getRollno()+"\n");
            writer.write(records.getFirstName()+"\n");
            writer.write(records.getLastName()+"\n");
            writer.write(records.getEng()+"\n");
            writer.write(records.getMaths()+"\n");
            writer.write(records.getPhy()+"\n");
            writer.write(records.getChem()+"\n");
            writer.write(records.getComp()+"\n");
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (InputMismatchException e)
        {
            e.printStackTrace();
        }
    }
}
