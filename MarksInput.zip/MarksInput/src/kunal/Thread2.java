package kunal;

/**
 * Created by kunal on 19-08-2017.
 */
public class Thread2 extends Thread{
    @Override
    public void run() {
        ReadRollno readRollno=new ReadRollno();
        readRollno.checkRollNo();
    }
}
