package kunal;

/**
 * Created by kunal on 19-08-2017.
 */
public class Thread1 extends Thread{
    public void run()
    {
        Menu m=new Menu();
        m.runMenu();
    }
}
