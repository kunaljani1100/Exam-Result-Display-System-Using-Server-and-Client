package kunal;

import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.*;
import java.net.DatagramPacket;


/**
 * Created by kunal on 19-08-2017.
 */
public class ReadRollno {
    private String rno;
    private String rollno;
    private String firstName;
    private String lastName;
    private String eng;
    private String maths;
    private String phy;
    private String chem;
    private String comp;
    public void checkRollNo()
    {
        try
        {
            DatagramSocket socket=new DatagramSocket(5000);
            DatagramSocket socket2=new DatagramSocket();
            InetAddress address=InetAddress.getLocalHost();
            while(true)
            {
                byte []buffer=new byte[7];
                DatagramPacket packet=new DatagramPacket(buffer,buffer.length);
                socket.receive(packet);
                rno=new String(buffer);
                try(BufferedReader reader=new BufferedReader(new FileReader(rno+".txt")))
                {
                    rollno="Roll no:"+reader.readLine();
                    byte buff[]=rollno.getBytes();
                    DatagramPacket packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    firstName="First Name:"+reader.readLine();
                    buff=firstName.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    lastName="Last Name:"+reader.readLine();
                    buff=lastName.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    eng="English:"+reader.readLine();
                    buff=eng.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    maths="Mathematics:"+reader.readLine();
                    buff=maths.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    phy="Physics:"+reader.readLine();
                    buff=phy.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    chem="Chemistry:"+reader.readLine();
                    buff=chem.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    comp="Computer:"+reader.readLine();
                    buff=comp.getBytes();
                    packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                    reader.close();
                }
                catch (FileNotFoundException e)
                {
                    System.out.println("File not found.");
                    byte buff[]=("Invalid roll no.").getBytes();
                    DatagramPacket packet2=new DatagramPacket(buff,buff.length,address,4000);
                    socket2.send(packet2);
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
