package kunal;

import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Created by kunal on 19-08-2017.
 */
public class StudentMarks{
    Scanner scanner=new Scanner(System.in);
    private String rollno;
    private String firstName;
    private String lastName;
    private int eng;
    private int maths;
    private int phy;
    private int chem;
    private int comp;
    public void readMarks()
    {
        int check;
        try
        {
            System.out.println("Enter Roll Number:");
            rollno = scanner.nextLine();
            check=Integer.parseInt(rollno);
            System.out.println("Enter First Name:");
            firstName=scanner.nextLine();
            System.out.println("Enter Last Name:");
            lastName=scanner.nextLine();
            System.out.println("Enter english Marks:");
            eng=scanner.nextInt();
            System.out.println("Enter mathematics marks:");
            maths=scanner.nextInt();
            System.out.println("Enter physics marks:");
            phy=scanner.nextInt();
            System.out.println("Enter chemistry marks:");
            chem=scanner.nextInt();
            System.out.println("Enter computer marks:");
            comp=scanner.nextInt();
        }
        catch(InputMismatchException e)
        {
            System.out.println("Wrong input.");
        }
        catch (NumberFormatException e)
        {
            System.out.println("Wrong input.");
        }
    }
    public String getRollno()
    {
        return rollno;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getEng() {
        return eng;
    }

    public int getMaths() {
        return maths;
    }

    public int getPhy() {
        return phy;
    }

    public int getChem() {
        return chem;
    }

    public int getComp() {
        return comp;
    }
}
