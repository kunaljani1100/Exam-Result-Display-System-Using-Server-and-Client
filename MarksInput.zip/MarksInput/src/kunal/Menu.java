package kunal;

import java.util.Scanner;

/**
 * Created by kunal on 19-08-2017.
 */
public class Menu {
    public void runMenu()
    {
        Scanner scanner=new Scanner(System.in);
        int choice=0;
        WriteMarksToFile writeMarksToFile=new WriteMarksToFile();
        ChangeMarks changeMarks=new ChangeMarks();
        while(choice!=3)
        {
            System.out.println("1.Enter new record:");
            System.out.println("2.Change existing record:");
            System.out.println("3.Exit");
            choice=scanner.nextInt();
            if(choice==1)
            {
                writeMarksToFile.write();
            }
            else if(choice==2)
            {
                changeMarks.change();
            }
            else
            {
                System.exit(0);
            }
        }
    }
}
